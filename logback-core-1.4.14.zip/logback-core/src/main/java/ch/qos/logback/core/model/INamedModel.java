package ch.qos.logback.core.model;

public interface INamedModel {

    public String getName();

    public void setName(String name);

}

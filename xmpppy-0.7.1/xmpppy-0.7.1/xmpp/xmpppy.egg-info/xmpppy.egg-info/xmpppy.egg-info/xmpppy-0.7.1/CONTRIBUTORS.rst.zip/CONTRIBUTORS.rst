#######
Authors
#######
``xmpppy`` has been conceived and maintained by

- Alexey Nezhdanov <snakeru@gmail.com>
- Norman Rasmussen <norman@rasmussen.co.za>

with the help of many others.


############
Contributors
############

This is an alphabetically-ordered list of the people who directly
contributed to xmpppy in one way or another.

- Andreas Motl <andreas.motl@panodata.org>
- Brendan Sleight
- Brian Tipton
- Daniel Wozniak <dan@orvant.com>
- Daryl Herzmann
- David Ammouial <da@weeno.net>
- Gabriel Ebner <gebner@2b7e.org>
- Iván Lloro
- Ivan Vučica <ivan@vucica.net>
- James Wu <jamesw@minted.com>
- Johan Bakker <johan@provonet.org>
- Justin Forest <justin.forest@gmail.com>
- Jörg Thalheim <joerg@higgsboson.tk>
- Marek Kubica
- Martin Thomas
- Michael Taboada <michael@michaels.world>
- Michał Pasternak <michal.dtz@gmail.com>
- Mike Albon <mikea@yuri.org.uk>
- Rulexec <rulix.exec@gmail.com>
- Soren Roug
- Stanislav Gorbenko <xenginex@gmail.com>
- Stefan Fritze (@rogue73)
- Vladimir Osintsev <oc@co.ru>
- asterix
- iamsudip <iamsudip@programmer.net>
- dkm
- dwd
- google
- randomthoughts
- sneakin
- thorstenp

Thanks a bunch!
